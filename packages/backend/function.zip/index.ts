// Repo: @johnforfar/aws-intent-dashboard File: /packages/backend/index.ts

import { APIGatewayProxyHandler } from 'aws-lambda';
import * as AWS from 'aws-sdk';

const dynamodb = new AWS.DynamoDB.DocumentClient();

console.log('Starting the backend service...');

export const handler: APIGatewayProxyHandler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  if (event.path === '/api/intents') {
    try {
      console.log('Fetching intents from DynamoDB...');
      const params = {
        TableName: 'Intents',
        Limit: 10
      };

      const result = await dynamodb.scan(params).promise();
      console.log('Fetched intents:', JSON.stringify(result.Items, null, 2));

      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*', // Add CORS headers
          'Access-Control-Allow-Headers': 'Content-Type',
        },
        body: JSON.stringify(result.Items),
      };
    } catch (error) {
      console.error('Error fetching intents:', error);
      return {
        statusCode: 500,
        headers: {
          'Access-Control-Allow-Origin': '*', // Add CORS headers
          'Access-Control-Allow-Headers': 'Content-Type',
        },
        body: JSON.stringify({ message: 'Internal server error' }),
      };
    }
  } else {
    console.log('Path not found:', event.path);
    return {
      statusCode: 404,
      headers: {
        'Access-Control-Allow-Origin': '*', // Add CORS headers
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify({ message: 'Not Found' }),
    };
  }
};

console.log('Backend service started.');