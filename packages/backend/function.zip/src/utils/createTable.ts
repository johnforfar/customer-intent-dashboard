// Repo: @johnforfar/aws-intent-dashboard File: /packages/backend/src/createTable.ts
import * as AWS from 'aws-sdk';

AWS.config.update({
  region: process.env.AWS_DEFAULT_REGION || 'ap-southeast-4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || 'test',
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || 'test',
});

const dynamodb = new AWS.DynamoDB({
    endpoint: process.env.AWS_ENDPOINT_URL || 'http://localhost:4566',
  });

const params = {
  TableName: 'Intents',
  KeySchema: [
    { AttributeName: 'id', KeyType: 'HASH' },  // Partition key
  ],
  AttributeDefinitions: [
    { AttributeName: 'id', AttributeType: 'S' },
  ],
  ProvisionedThroughput: {
    ReadCapacityUnits: 5,
    WriteCapacityUnits: 5,
  },
};

dynamodb.createTable(params, (err, data) => {
  if (err) {
    console.error('Unable to create table. Error JSON:', JSON.stringify(err, null, 2));
  } else {
    console.log('Created table. Table description JSON:', JSON.stringify(data, null, 2));
  }
});