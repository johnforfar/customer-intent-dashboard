// Repo: @johnforfar/aws-intent-dashboard File: /packages/backend/src/uploadData.ts
import * as AWS from 'aws-sdk';
import * as fs from 'fs';
import * as uuid from 'uuid';

// Log environment variables to verify they are set correctly
console.log('AWS_DEFAULT_REGION:', process.env.AWS_DEFAULT_REGION);
console.log('AWS_ACCESS_KEY_ID:', process.env.AWS_ACCESS_KEY_ID);
console.log('AWS_SECRET_ACCESS_KEY:', process.env.AWS_SECRET_ACCESS_KEY);
console.log('AWS_ENDPOINT_URL:', process.env.AWS_ENDPOINT_URL);

AWS.config.update({
  region: process.env.AWS_DEFAULT_REGION || 'ap-southeast-4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || 'test',
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || 'test',
});

const docClient = new AWS.DynamoDB.DocumentClient({
    endpoint: 'http://localhost:4566',
  });
const tableName = 'Intents';

interface Intent {
    id: string;
    intent: string;
  }

const uploadData = async () => {
const data = fs.readFileSync('dataset.txt', 'utf8');
const intents: Intent[] = data.split('\n').map((intent: string) => ({
    id: uuid.v4(),
    intent: intent.trim(),
}));

for (const item of intents) {
    const params = {
    TableName: tableName,
    Item: item,
    };

    try {
    await docClient.put(params).promise();
    console.log(`Added item: ${item.intent}`);
    } catch (err) {
    console.error(`Unable to add item: ${item.intent}. Error JSON:`, JSON.stringify(err, null, 2));
    }
}
};

uploadData();