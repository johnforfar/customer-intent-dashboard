// Repo: @johnforfar/aws-intent-dashboard File: /packages/backend/src/verifyData.ts
import * as AWS from 'aws-sdk';

AWS.config.update({
  region: process.env.AWS_DEFAULT_REGION || 'ap-southeast-4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || 'test',
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || 'test',
});

const docClient = new AWS.DynamoDB.DocumentClient({
  endpoint: process.env.AWS_ENDPOINT_URL || 'http://localhost:4566',
});

const tableName = 'Intents';

const verifyData = async () => {
  const params = {
    TableName: tableName,
  };

  try {
    const data = await docClient.scan(params).promise();
    console.log('Scan succeeded. Data:', JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('Unable to scan the table. Error JSON:', JSON.stringify(err, null, 2));
  }
};

verifyData();